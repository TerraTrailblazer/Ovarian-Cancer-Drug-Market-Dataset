# Ovarian Cancer Drug Market Dataset

This repository contains a small dataset and supporting files created from the *public* summary of the **Ovarian Cancer Drug Market** report on Next Move Strategy Consulting (NextMSC). The dataset is intended for research, prototyping, and demonstration purposes. It includes extracted market figures, segmentation summary, metadata, and the original source reference.

**Source:** Next Move Strategy Consulting — Ovarian Cancer Drug Market.  
**Report page:** https://www.nextmsc.com/report/ovarian-cancer-drug-market-hc3577

## Dataset Contents
- `market_overview.csv` — key extracted fields: market sizes (2024, 2025, 2030) and CAGR.  
- `segmentation.csv` — segmentation categories (Drug class, Route, Line of therapy, Distribution, Region).  
- `metadata.json` — structured metadata about extraction date, source, and files included.  
- `README.md` — this file.

## How to use the dataset
1. Download and unzip the archive.  
2. Inspect `market_overview.csv` for headline figures.  
3. Use `segmentation.csv` for categorical breakdowns.  
4. Cite the original report if you use data or insights from the full report.

## Key figures (from NextMSC public summary)
- **Market Size (2024):** USD **4.71 billion**.  
- **Estimated Market Size (2025):** USD **5.21 billion**.  
- **Projected Market Size (2030):** USD **8.58 billion**.  
- **Forecast CAGR (2025–2030):** **10.50%**.

## Limitations & Disclaimer
- This dataset contains only publicly available information from the report summary as of the extraction date.  
- The original report is likely behind a paywall; this dataset does **not** include the full PDF, proprietary tables, or paid content.  
- Use this dataset for research and educational purposes only; verify with the primary report before using in commercial or high‑stakes applications.

## License
This dataset is provided for research and educational purposes. Please respect NextMSC's rights regarding the full report content.

---
Generated on 2025-12-09 by ChatGPT.
